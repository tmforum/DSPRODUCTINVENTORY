package tmf.org.dsmapi.mock;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.util.List;
import org.apache.commons.io.IOUtils;

public class Delete implements HttpHandler {

//    private static File logFile;
    private static String fileName = "notification.json";
    private static String filePath = "./log/";
    private static FilenameFilter logFileFilter = new FilenameFilter() {
        public boolean accept(File dir, String name) {
            return name.endsWith(fileName);
        }
    };

    public Delete() {
    }

    public synchronized void handle(HttpExchange httpExchange) throws IOException {

        String method = httpExchange.getRequestMethod();

        File directory = new File(filePath);

        File[] files = directory.listFiles(logFileFilter);


        if ("DELETE".equalsIgnoreCase(method)) {
            Headers responseHeaders = httpExchange.getResponseHeaders();
            responseHeaders.set("Content-Type", "application/json");
            responseHeaders.set("Accept", "application/json");
            responseHeaders.set("Access-Control-Allow-Origin", "*");
            responseHeaders.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            Headers requestHeaders = httpExchange.getRequestHeaders();
            if (!requestHeaders.isEmpty()) {
                if (requestHeaders.containsValue("Access-Control-Request-Headers")) {
                    List<String> heads = requestHeaders.get("Access-Control-Request-Headers");
                    responseHeaders.put("Access-Control-Allow-Headers", heads);
                }
            }
            httpExchange.sendResponseHeaders(200, 0);
            OutputStream responseBody = httpExchange.getResponseBody();
            for (int i = 0; files.length > i; i++) {
                File file = files[i];
                if (! file.delete()){
                    httpExchange.sendResponseHeaders(401, 0);
                    String msg = "Cannot delete file "+file.getName();
                    responseBody.write(msg.getBytes());
                    responseBody.close();
                    i = files.length+1;
                }
            }
        }
        httpExchange.close();
        System.gc();
    }
}

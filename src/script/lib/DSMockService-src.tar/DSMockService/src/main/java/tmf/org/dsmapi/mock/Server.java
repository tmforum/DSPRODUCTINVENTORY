package tmf.org.dsmapi.mock;

import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpServer;

public class Server {

    public static void main(String[] args) throws Exception {
        HttpServer server = null;
        if (args.length > 0) {
            server = HttpServer.create(new InetSocketAddress(Integer.valueOf(args[0])), 0);
        } else {
            server = HttpServer.create(new InetSocketAddress(Integer.valueOf(9000)), 0);
        }

        server.createContext("/listener", new Listener());
        server.createContext("/history", new History());
        server.createContext("/current", new Current());
//        server.setExecutor(null); // creates a default executor
        server.setExecutor(java.util.concurrent.Executors. newFixedThreadPool(5)); 
        server.start();
    }
}
package tmf.org.dsmapi.mock.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.xml.bind.JAXBException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public final class JsonMapper {

    private static String jsonFileRepository = "/json/";


    public static void setJsonFileRepository(String jsonFileRepository) {
        JsonMapper.jsonFileRepository = jsonFileRepository;
    }

    public JsonMapper() {
    }

    /**
     *
     * @param jsonFile JSON file
     * @param pojo unMarshall object
     * @return 
     * @throws JAXBException, JsonParseException, JsonMappingException, IOException
     */
    public static Object jsonToPojo(File jsonFile, Object pojo) throws JAXBException,
            JsonParseException, JsonMappingException, IOException {

        InputStream inputstream = new FileInputStream(jsonFile);
        
        BufferedReader in = new BufferedReader(new InputStreamReader(inputstream, "UTF8"));
        
        ObjectMapper objectMapper = new ObjectMapper();
        Object iup = objectMapper.readValue(in, pojo.getClass());
        return iup;
    }
    
    /**
     *
     * @param pojo marshall object
     * @return 
     * @throws JAXBException, JsonParseException, JsonMappingException, IOException
     */
    public static String pojoToJson(Object obj) throws JAXBException,
            JsonParseException, JsonMappingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = objectMapper.writeValueAsString(obj);
        return jsonString;
    }


    public static void main(String[] args) {
            JsonMapper util = new JsonMapper();
    }
}
package tmf.org.dsmapi.mock;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import org.apache.commons.io.IOUtils;

public class Current implements HttpHandler {

//    private static File logFile;
    private static String fileName = "notification.json";
    private static String filePath = "./log/";
    private static FilenameFilter logFileFilter = new FilenameFilter() {
        public boolean accept(File dir, String name) {
            return name.endsWith(fileName);
        }
    };

    public Current() {
    }

    public synchronized void handle(HttpExchange httpExchange) throws IOException {

        String method = httpExchange.getRequestMethod();

        File directory = new File(filePath);

        File[] files = directory.listFiles(logFileFilter);
//        String logFile = filePath.concat("2014-09-22T15-27-23UTC".concat(fileName));
        File mostRecentFile = null;

        if ("GET".equalsIgnoreCase(method)) {
            Headers responseHeaders = httpExchange.getResponseHeaders();
            responseHeaders.set("Content-Type", "application/json");
            httpExchange.sendResponseHeaders(200, 0);
            OutputStream responseBody = httpExchange.getResponseBody();
            FileInputStream logFile = null;
            if (files.length > 0) {
                mostRecentFile = files[0];
                for (int i = 0; files.length > i; i++) {
                    File file = files[i];
                    if (file.lastModified() > mostRecentFile.lastModified()) {
                        mostRecentFile = file;
                    }
                }
                logFile = new FileInputStream(mostRecentFile);
                responseBody.write(IOUtils.toByteArray(logFile));
            }
//            FileInputStream file = new FileInputStream(logFile);
//            responseBody.write(IOUtils.toByteArray(file));
//            file.close();
            responseBody.write("]\n".getBytes());
            responseBody.close();
            logFile.close();
        }

//        info = "\n" + Format.toString(new Date()) + " --- FINITO --- \n\n";
        //System.out.print(info);
//        logOutS.write(info.getBytes());
//        logOutS.close();
//        logOutS = null;
        System.gc();
//        t.sendResponseHeaders(201, 0);
//        t.getResponseBody().close();
    }
}

package tmf.org.dsmapi.mock;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import tmf.org.dsmapi.mock.utils.Format;

import java.io.*;
import java.util.Calendar;

public class Listener implements HttpHandler {

//    private static File logFile;
    private static String fileName = "notification.json";
    private static String filePath = "./log/";

    public Listener() {
    }

    public synchronized void handle(HttpExchange t) throws IOException {

        String method = t.getRequestMethod();

        Calendar calendar = Calendar.getInstance();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(calendar.getTime().getTime());
        String formatDate = Format.toString(currentTimestamp);

        String logFile = filePath.concat(formatDate.concat(fileName));

        FileOutputStream logOutS = new FileOutputStream(logFile, true);

        if ("POST".equalsIgnoreCase(method)) {
            logOutS.write("\n".getBytes());
            InputStream bodyS = t.getRequestBody();
            byte[] buffer = new byte[256];
            int bytesRead = 0;
            while ((bytesRead = bodyS.read(buffer)) != -1) {
                logOutS.write(buffer, 0, bytesRead);
            }
            logOutS.close();
            logOutS = null;
            System.gc();

            t.sendResponseHeaders(201, 0);
            t.getResponseBody().close();
        }


    }
}
